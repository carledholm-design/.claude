import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useTheme } from '@/context/ThemeContext';
import type { NavTab } from '@/constants/tokens';

interface PlaceholderProps {
  tab: NavTab;
  onNavigate: (tab: NavTab) => void;
}

function PlaceholderScreen({ tab, icon, sub }: { tab: string; icon: string; sub: string }) {
  const { colors } = useTheme();
  return (
    <View style={[styles.screen, { backgroundColor: colors.bg }]}>
      <Text style={styles.icon}>{icon}</Text>
      <Text style={[styles.title, { color: colors.onSurface }]}>{tab}</Text>
      <Text style={[styles.sub, { color: colors.onSurface2 }]}>{sub}</Text>
    </View>
  );
}

export function HealthScreen({ onNavigate }: PlaceholderProps) {
  return <PlaceholderScreen tab="Health" icon="📊" sub="Conditions, labs, care team" />;
}

export function MedsScreen({ onNavigate }: PlaceholderProps) {
  return <PlaceholderScreen tab="Meds" icon="💊" sub="Medications, supplements, interactions" />;
}

export function VitalsScreen({ onNavigate }: PlaceholderProps) {
  return <PlaceholderScreen tab="Vitals" icon="❤️" sub="Blood pressure, heart rate, weight" />;
}

export function WalletScreen({ onNavigate }: PlaceholderProps) {
  return <PlaceholderScreen tab="Wallet" icon="💳" sub="Insurance, FSA/HSA, Emergency Card" />;
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  icon: { fontSize: 48 },
  title: { fontSize: 24, fontWeight: '300' },
  sub: { fontSize: 14, textAlign: 'center', paddingHorizontal: 40 },
});
