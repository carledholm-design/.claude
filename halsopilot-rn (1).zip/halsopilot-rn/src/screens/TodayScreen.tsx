import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Animated, PanResponder,
} from 'react-native';
import { useTheme } from '@/context/ThemeContext';
import { useToast } from '@/context/ToastContext';
import { SectionRow } from '@/components/shared/SectionRow';
import { BottomSheet } from '@/components/shared/BottomSheet';
import { Spacing, Radius } from '@/constants/tokens';
import type { NavTab } from '@/constants/tokens';

interface TodayScreenProps {
  onNavigate: (tab: NavTab) => void;
}

// ── Mock data ─────────────────────────────────────────────────────────
const CONDITIONS = [
  { id: 'c1', name: 'Rheumatoid Arthritis', color: '#3D7A8A' },
  { id: 'c2', name: 'Hashimoto\'s', color: '#4A7C5F' },
  { id: 'c3', name: 'Fibromyalgia', color: '#7A6444' },
];

const TODAY_MEDS = [
  { id: 'm1', name: 'Methotrexate', dose: '15mg', time: '8:00 AM', taken: false, type: 'med' },
  { id: 'm2', name: 'Levothyroxine', dose: '88mcg', time: '6:30 AM', taken: true, type: 'med' },
  { id: 'm3', name: 'Vitamin D3', dose: '2000IU', time: '8:00 AM', taken: false, type: 'supplement' },
];

const APPOINTMENTS = [
  { id: 'a1', title: 'Rheumatology Follow-up', doctor: 'Dr. Anna Eriksson', time: '2:30 PM', location: 'NYU Langone', color: '#3D7A8A' },
  { id: 'a2', title: 'Blood Work · CBC Panel', doctor: 'Quest Diagnostics', time: '4:00 PM', location: '65th St', color: '#4A7C5F' },
];

const REFILLS = [
  { id: 'r1', name: 'Methotrexate', dose: '15mg', daysLeft: 3, pharmacy: 'CVS · 72nd St', urgent: true },
  { id: 'r2', name: 'Levothyroxine', dose: '88mcg', daysLeft: 7, pharmacy: 'Walgreens · 5th Ave', urgent: false },
];

const MOODS = ['😣','😔','😐','🙂','😊'];
const PAIN_LEVELS = [1,2,3,4,5,6,7,8,9,10];

export function TodayScreen({ onNavigate }: TodayScreenProps) {
  const { colors } = useTheme();
  const { toast } = useToast();

  const [takenMeds, setTakenMeds] = useState<Set<string>>(new Set(['m2']));
  const [selectedMood, setSelectedMood] = useState<number | null>(null);
  const [selectedPain, setSelectedPain] = useState<number | null>(null);
  const [checkedIn, setCheckedIn] = useState(false);
  const [snoozeSheet, setSnoozeSheet] = useState<{ visible: boolean; name: string; id: string }>({ visible: false, name: '', id: '' });
  const [rescheduleSheet, setRescheduleSheet] = useState<{ visible: boolean; name: string }>({ visible: false, name: '' });

  const markTaken = useCallback((id: string, name: string) => {
    setTakenMeds(prev => new Set([...prev, id]));
    toast('success', `${name} logged`, 'Marked as taken');
  }, [toast]);

  const openSnooze = useCallback((id: string, name: string) => {
    setSnoozeSheet({ visible: true, name, id });
  }, []);

  const openReschedule = useCallback((name: string) => {
    setRescheduleSheet({ visible: true, name });
  }, []);

  const logCheckin = useCallback(() => {
    if (selectedMood === null || selectedPain === null) {
      toast('warning', 'Select mood and pain', 'Both are required');
      return;
    }
    setCheckedIn(true);
    toast('success', 'Check-in logged', `Mood ${MOODS[selectedMood]} · Pain ${selectedPain}/10`);
  }, [selectedMood, selectedPain, toast]);

  const now = new Date();
  const greeting = now.getHours() < 12 ? 'Good morning' : now.getHours() < 17 ? 'Good afternoon' : 'Good evening';
  const dateStr = now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });

  return (
    <>
      <ScrollView
        style={[styles.screen, { backgroundColor: colors.bg }]}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* Page header */}
        <View style={styles.pageHeader}>
          <View>
            <Text style={[styles.greeting, { color: colors.onSurface }]}>{greeting}</Text>
            <Text style={[styles.dateStr, { color: colors.onSurface2 }]}>{dateStr}</Text>
          </View>
          {/* Avatar */}
          <View style={[styles.avatar, { backgroundColor: colors.primaryC }]}>
            <Text style={[styles.avatarText, { color: colors.primary }]}>AP</Text>
          </View>
        </View>

        {/* ── AI Insight card ── */}
        <TouchableOpacity
          style={[styles.insightCard, { backgroundColor: colors.primaryC }]}
          onPress={() => onNavigate('Today')}
          activeOpacity={0.85}
        >
          <View style={styles.insightTop}>
            <View style={[styles.insightIcon, { backgroundColor: colors.primary }]}>
              <Text style={{ color: '#fff', fontSize: 12 }}>✦</Text>
            </View>
            <Text style={[styles.insightTag, { color: colors.primary }]}>AI Insight · this week</Text>
          </View>
          <Text style={[styles.insightText, { color: colors.onSurface }]}>
            Your pain has been moderate for 9 days, coinciding with your Methotrexate dose increase on March 4th.
          </Text>
          <Text style={[styles.insightAction, { color: colors.primary }]}>
            Worth mentioning at today's appointment with Dr. Eriksson ›
          </Text>
        </TouchableOpacity>

        {/* ── Daily check-in ── */}
        {!checkedIn ? (
          <View style={[styles.checkinCard, { backgroundColor: colors.surface, borderColor: colors.outlineVar }]}>
            <Text style={[styles.checkinTitle, { color: colors.onSurface }]}>Daily check-in</Text>
            <Text style={[styles.checkinSub, { color: colors.onSurface2 }]}>How are you feeling today?</Text>

            {/* Mood */}
            <Text style={[styles.checkinLabel, { color: colors.outline }]}>MOOD</Text>
            <View style={styles.moodRow}>
              {MOODS.map((m, i) => (
                <TouchableOpacity
                  key={i}
                  onPress={() => setSelectedMood(i)}
                  style={[
                    styles.moodBtn,
                    selectedMood === i && { backgroundColor: colors.primaryC, borderColor: colors.primary }
                  ]}
                >
                  <Text style={styles.moodEmoji}>{m}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Pain */}
            <Text style={[styles.checkinLabel, { color: colors.outline }]}>PAIN LEVEL</Text>
            <View style={styles.painRow}>
              {PAIN_LEVELS.map(p => (
                <TouchableOpacity
                  key={p}
                  onPress={() => setSelectedPain(p)}
                  style={[
                    styles.painBtn,
                    { backgroundColor: selectedPain === p ? colors.error : colors.surfaceVar }
                  ]}
                >
                  <Text style={[styles.painNum, { color: selectedPain === p ? '#fff' : colors.onSurface2 }]}>{p}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <TouchableOpacity
              style={[styles.checkinBtn, { backgroundColor: colors.primary }]}
              onPress={logCheckin}
            >
              <Text style={styles.checkinBtnText}>Log check-in</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={[styles.checkinDone, { backgroundColor: colors.secondaryC, borderColor: colors.outlineVar }]}>
            <Text style={[styles.checkinDoneText, { color: colors.secondary }]}>
              ✓ Checked in · {MOODS[selectedMood!]} mood · {selectedPain}/10 pain
            </Text>
          </View>
        )}

        {/* ── Active Conditions ── */}
        <SectionRow
          label="Active conditions"
          actionLabel="See all"
          onAction={() => onNavigate('Health')}
        />
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={styles.conditionStrip}>
            {CONDITIONS.map(c => (
              <View key={c.id} style={[styles.condPill, { backgroundColor: c.color + '22' }]}>
                <View style={[styles.condDot, { backgroundColor: c.color }]} />
                <Text style={[styles.condName, { color: c.color }]}>{c.name}</Text>
              </View>
            ))}
          </View>
        </ScrollView>

        {/* ── Today's meds ── */}
        <SectionRow
          label="Today's medications"
          actionLabel="All meds"
          onAction={() => onNavigate('Meds')}
        />
        {TODAY_MEDS.map(med => {
          const taken = takenMeds.has(med.id);
          return (
            <MedCard
              key={med.id}
              med={med}
              taken={taken}
              onMarkTaken={() => markTaken(med.id, med.name)}
              onSnooze={() => openSnooze(med.id, med.name)}
            />
          );
        })}

        {/* ── Upcoming appointments ── */}
        <SectionRow
          label="Upcoming appointments"
          actionLabel="Calendar"
          onAction={() => onNavigate('Health')}
        />
        {APPOINTMENTS.map(appt => (
          <ApptCard
            key={appt.id}
            appt={appt}
            onReschedule={() => openReschedule(appt.title)}
          />
        ))}

        {/* ── Refill reminders ── */}
        <SectionRow
          label="Refill reminders"
          actionLabel="All meds"
          onAction={() => onNavigate('Meds')}
        />
        {REFILLS.map(refill => (
          <RefillCard
            key={refill.id}
            refill={refill}
            onSnooze={() => openSnooze(refill.id, refill.name)}
            onOrder={() => toast('success', 'Refill requested', `${refill.name} · ${refill.pharmacy}`)}
          />
        ))}

        <View style={{ height: 40 }} />
      </ScrollView>

      {/* ── Snooze sheet ── */}
      <BottomSheet
        visible={snoozeSheet.visible}
        onClose={() => setSnoozeSheet(s => ({ ...s, visible: false }))}
        title="Snooze reminder"
      >
        <Text style={{ fontSize: 13, color: '#524F4A', marginBottom: 20 }}>{snoozeSheet.name}</Text>
        {[
          { label: '30 minutes', mins: 30 },
          { label: '1 hour',     mins: 60 },
          { label: '2 hours',    mins: 120 },
          { label: '4 hours',    mins: 240 },
          { label: '8 hours',    mins: 480 },
        ].map(opt => (
          <TouchableOpacity
            key={opt.mins}
            style={styles.snoozeOpt}
            onPress={() => {
              setSnoozeSheet(s => ({ ...s, visible: false }));
              toast('info', `Snoozed ${opt.label}`, `${snoozeSheet.name} · back in ${opt.label}`);
            }}
          >
            <Text style={styles.snoozeOptText}>{opt.label}</Text>
          </TouchableOpacity>
        ))}
      </BottomSheet>

      {/* ── Reschedule sheet ── */}
      <BottomSheet
        visible={rescheduleSheet.visible}
        onClose={() => setRescheduleSheet(s => ({ ...s, visible: false }))}
        title="Reschedule appointment"
      >
        <Text style={{ fontSize: 13, color: '#524F4A', marginBottom: 20 }}>
          {rescheduleSheet.name}
        </Text>
        <Text style={{ fontSize: 13, color: '#918E87', marginBottom: 16 }}>
          Select a new date and time — your provider will be notified.
        </Text>
        <TouchableOpacity
          style={[styles.ctaBtn, { backgroundColor: '#3D7A8A' }]}
          onPress={() => {
            setRescheduleSheet(s => ({ ...s, visible: false }));
            toast('success', 'Appointment rescheduled', rescheduleSheet.name);
          }}
        >
          <Text style={styles.ctaBtnText}>Confirm reschedule</Text>
        </TouchableOpacity>
      </BottomSheet>
    </>
  );
}

// ── Sub-components ────────────────────────────────────────────────────

function MedCard({ med, taken, onMarkTaken, onSnooze }: {
  med: typeof TODAY_MEDS[0];
  taken: boolean;
  onMarkTaken: () => void;
  onSnooze: () => void;
}) {
  const { colors } = useTheme();
  return (
    <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.outlineVar, opacity: taken ? 0.5 : 1 }]}>
      <View style={styles.cardLeft}>
        <View style={[styles.cardIcon, { backgroundColor: med.type === 'supplement' ? colors.tertiaryC : colors.primaryC }]}>
          <Text style={{ fontSize: 14 }}>{med.type === 'supplement' ? '💊' : '💊'}</Text>
        </View>
        <View>
          <Text style={[styles.cardTitle, { color: colors.onSurface }]}>{med.name}</Text>
          <Text style={[styles.cardSub, { color: colors.onSurface2 }]}>{med.dose} · {med.time}</Text>
        </View>
      </View>
      {!taken ? (
        <View style={styles.cardActions}>
          <TouchableOpacity onPress={onSnooze} style={[styles.cardActionBtn, { backgroundColor: colors.surfaceVar }]}>
            <Text style={[styles.cardActionText, { color: colors.onSurface2 }]}>Later</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onMarkTaken} style={[styles.cardActionBtn, { backgroundColor: colors.secondaryC }]}>
            <Text style={[styles.cardActionText, { color: colors.secondary }]}>Taken ✓</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <Text style={[styles.takenBadge, { color: colors.secondary }]}>✓ Taken</Text>
      )}
    </View>
  );
}

function ApptCard({ appt, onReschedule }: {
  appt: typeof APPOINTMENTS[0];
  onReschedule: () => void;
}) {
  const { colors } = useTheme();
  return (
    <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.outlineVar }]}>
      <View style={[styles.apptAccent, { backgroundColor: appt.color }]} />
      <View style={styles.cardLeft}>
        <View>
          <Text style={[styles.cardTitle, { color: colors.onSurface }]}>{appt.title}</Text>
          <Text style={[styles.cardSub, { color: colors.onSurface2 }]}>{appt.time} · {appt.location}</Text>
        </View>
      </View>
      <TouchableOpacity onPress={onReschedule} style={[styles.cardActionBtn, { backgroundColor: colors.surfaceVar }]}>
        <Text style={[styles.cardActionText, { color: colors.onSurface2 }]}>Reschedule</Text>
      </TouchableOpacity>
    </View>
  );
}

function RefillCard({ refill, onSnooze, onOrder }: {
  refill: typeof REFILLS[0];
  onSnooze: () => void;
  onOrder: () => void;
}) {
  const { colors } = useTheme();
  const bg = refill.urgent ? colors.errorC : colors.surface;
  const border = refill.urgent ? colors.error : colors.outlineVar;
  return (
    <View style={[styles.card, { backgroundColor: bg, borderColor: border }]}>
      <View style={styles.cardLeft}>
        <View>
          <Text style={[styles.cardTitle, { color: colors.onSurface }]}>{refill.name} {refill.dose}</Text>
          <Text style={[styles.cardSub, { color: refill.urgent ? colors.error : colors.onSurface2 }]}>
            {refill.urgent ? `⚠ ${refill.daysLeft} days left` : `${refill.daysLeft} days left`} · {refill.pharmacy}
          </Text>
        </View>
      </View>
      <View style={styles.cardActions}>
        <TouchableOpacity onPress={onSnooze} style={[styles.cardActionBtn, { backgroundColor: colors.surfaceVar }]}>
          <Text style={[styles.cardActionText, { color: colors.onSurface2 }]}>Later</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={onOrder} style={[styles.cardActionBtn, { backgroundColor: colors.secondaryC }]}>
          <Text style={[styles.cardActionText, { color: colors.secondary }]}>Order</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 20, paddingTop: 4, paddingBottom: 120 },

  pageHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 18 },
  greeting: { fontSize: 24, fontWeight: '300' },
  dateStr:  { fontSize: 13, marginTop: 2 },
  avatar:   { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 14, fontWeight: '600' },

  // Insight card
  insightCard: { borderRadius: 24, padding: 18, marginBottom: 4 },
  insightTop: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  insightIcon: { width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  insightTag: { fontSize: 11, fontWeight: '600' },
  insightText: { fontSize: 14, lineHeight: 22, marginBottom: 10 },
  insightAction: { fontSize: 12, fontWeight: '600' },

  // Check-in
  checkinCard: { borderRadius: 20, padding: 18, borderWidth: 0.5, marginBottom: 4 },
  checkinTitle: { fontSize: 16, fontWeight: '600', marginBottom: 4 },
  checkinSub: { fontSize: 13, marginBottom: 16 },
  checkinLabel: { fontSize: 10, fontWeight: '700', letterSpacing: 1.5, marginBottom: 8 },
  moodRow: { flexDirection: 'row', gap: 8, marginBottom: 16 },
  moodBtn: { flex: 1, alignItems: 'center', padding: 10, borderRadius: 12, borderWidth: 1.5, borderColor: 'transparent' },
  moodEmoji: { fontSize: 24 },
  painRow: { flexDirection: 'row', gap: 4, marginBottom: 20, flexWrap: 'wrap' },
  painBtn: { width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  painNum: { fontSize: 12, fontWeight: '600' },
  checkinBtn: { borderRadius: 100, padding: 14, alignItems: 'center' },
  checkinBtnText: { color: '#fff', fontSize: 15, fontWeight: '600' },
  checkinDone: { borderRadius: 12, padding: 14, borderWidth: 0.5, marginBottom: 4, alignItems: 'center' },
  checkinDoneText: { fontSize: 13, fontWeight: '500' },

  // Conditions strip
  conditionStrip: { flexDirection: 'row', gap: 8, paddingBottom: 4 },
  condPill: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 100 },
  condDot: { width: 7, height: 7, borderRadius: 4 },
  condName: { fontSize: 13, fontWeight: '500' },

  // Cards
  card: { flexDirection: 'row', alignItems: 'center', borderRadius: 16, padding: 14, borderWidth: 0.5, marginBottom: 8, gap: 12 },
  cardLeft: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12 },
  cardIcon: { width: 38, height: 38, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  cardTitle: { fontSize: 14, fontWeight: '500' },
  cardSub: { fontSize: 12, marginTop: 2 },
  cardActions: { flexDirection: 'row', gap: 6 },
  cardActionBtn: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 100 },
  cardActionText: { fontSize: 12, fontWeight: '600' },
  takenBadge: { fontSize: 12, fontWeight: '600' },
  apptAccent: { width: 4, height: '100%', borderRadius: 2, position: 'absolute', left: 0, top: 0, bottom: 0 },

  // Snooze sheet
  snoozeOpt: { backgroundColor: '#E4E0D8', borderRadius: 12, padding: 16, marginBottom: 8, alignItems: 'center' },
  snoozeOptText: { fontSize: 15, fontWeight: '500', color: '#1C1B1A' },

  // CTA
  ctaBtn: { borderRadius: 100, padding: 15, alignItems: 'center' },
  ctaBtnText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});
