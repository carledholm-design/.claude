// hälsoPilot Design Tokens
// Swedish palette — never deviate from these

export const Colors = {
  // Primary — teal
  primary:     '#3D7A8A',
  primaryC:    '#C2E8F0',

  // Secondary — green
  secondary:   '#4A7C5F',
  secondaryC:  '#C5EAD3',

  // Tertiary — warm brown
  tertiary:    '#7A6444',
  tertiaryC:   '#F0DFC0',

  // Surfaces
  surface:     '#F6F3EE',
  surfaceVar:  '#E4E0D8',
  bg:          '#EDEAE3',

  // Content
  onSurface:   '#1C1B1A',
  onSurface2:  '#524F4A',

  // Borders
  outline:     '#918E87',
  outlineVar:  '#CAC6BE',

  // Error
  error:       '#BA1A1A',
  errorC:      '#FFDAD6',

  // Warning
  warn:        '#B45309',
  warnC:       '#FEF3C7',

  // Chrome (nav/header)
  chrome:      '#FFFFFF',
  chromeBorder:'#E8E4DD',

  // Dark mode overrides
  dark: {
    primary:     '#89D0E0',
    primaryC:    '#1E5060',
    secondary:   '#8ACBA8',
    secondaryC:  '#1E4A33',
    tertiary:    '#D9BF95',
    tertiaryC:   '#452E0F',
    surface:     '#1A1916',
    surfaceVar:  '#26231E',
    bg:          '#0E0D0C',
    onSurface:   '#E8E4DD',
    onSurface2:  '#B5B1AA',
    outline:     '#5A5750',
    outlineVar:  '#3A3730',
    error:       '#FFB4AB',
    errorC:      '#690005',
    chrome:      '#1A1916',
    chromeBorder:'#26231E',
  },
} as const;

export const Spacing = {
  xs:  4,
  sm:  8,
  md:  12,
  lg:  16,
  xl:  20,
  xxl: 24,
  xxxl:32,
} as const;

export const Radius = {
  sm:   8,
  md:   12,
  lg:   16,
  xl:   20,
  xxl:  24,
  pill: 100,
} as const;

export const Typography = {
  // Page title
  pageTitle: {
    fontSize: 28,
    fontWeight: '300' as const,
    letterSpacing: -0.5,
  },
  // Section label
  sectionLabel: {
    fontSize: 10,
    fontWeight: '700' as const,
    letterSpacing: 2,
    textTransform: 'uppercase' as const,
  },
  // Card title
  cardTitle: {
    fontSize: 15,
    fontWeight: '600' as const,
  },
  // Body
  body: {
    fontSize: 14,
    fontWeight: '400' as const,
  },
  // Body medium
  bodyMedium: {
    fontSize: 14,
    fontWeight: '500' as const,
  },
  // Caption
  caption: {
    fontSize: 12,
    fontWeight: '400' as const,
  },
  // Label small
  labelSmall: {
    fontSize: 11,
    fontWeight: '600' as const,
  },
  // Nav label
  navLabel: {
    fontSize: 10,
    fontWeight: '500' as const,
  },
} as const;

export const Shadows = {
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  sheet: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.1,
    shadowRadius: 16,
    elevation: 8,
  },
} as const;

// Nav tabs — locked, never change
export const NAV_TABS = [
  { key: 'Today',  label: 'Today'  },
  { key: 'Health', label: 'Health' },
  { key: 'Meds',   label: 'Meds'   },
  { key: 'Vitals', label: 'Vitals' },
  { key: 'Wallet', label: 'Wallet' },
] as const;

export type NavTab = typeof NAV_TABS[number]['key'];
