import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme } from '@/context/ThemeContext';
import { NAV_TABS, type NavTab } from '@/constants/tokens';
import { NavIcons } from './NavIcons';

interface BottomNavProps {
  activeTab: NavTab;
  onTabPress: (tab: NavTab) => void;
}

export function BottomNav({ activeTab, onTabPress }: BottomNavProps) {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();

  return (
    <View style={[
      styles.container,
      {
        backgroundColor: colors.chrome,
        borderTopColor: colors.chromeBorder,
        paddingBottom: Math.max(insets.bottom, 8),
      }
    ]}>
      {NAV_TABS.map(tab => {
        const isActive = activeTab === tab.key;
        const color = isActive ? colors.primary : colors.outline;

        return (
          <TouchableOpacity
            key={tab.key}
            style={styles.tab}
            onPress={() => onTabPress(tab.key)}
            activeOpacity={0.7}
          >
            {/* Active indicator bar at top */}
            <View style={[
              styles.indicator,
              { backgroundColor: colors.primary, opacity: isActive ? 1 : 0 }
            ]} />

            {/* Icon */}
            <View style={styles.iconWrap}>
              <NavIcons tab={tab.key} color={color} size={22} />
            </View>

            {/* Label */}
            <Text style={[styles.label, { color }]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    borderTopWidth: 0.5,
    paddingTop: 10,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    paddingTop: 4,
    position: 'relative',
  },
  indicator: {
    position: 'absolute',
    top: -10,
    width: 22,
    height: 3,
    borderRadius: 1.5,
  },
  iconWrap: {
    width: 26,
    height: 26,
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: {
    fontSize: 10,
    fontWeight: '500',
    marginTop: 3,
  },
});
