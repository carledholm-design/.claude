import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useTheme } from '@/context/ThemeContext';

interface AppHeaderProps {
  rightActions?: React.ReactNode;
}

export function AppHeader({ rightActions }: AppHeaderProps) {
  const { colors } = useTheme();

  return (
    <View style={[
      styles.container,
      { backgroundColor: colors.chrome, borderBottomColor: colors.chromeBorder }
    ]}>
      {/* Wordmark */}
      <View style={styles.wordmark}>
        <Text style={[styles.thin, { color: colors.onSurface }]}>hälso</Text>
        <Text style={[styles.bold, { color: colors.primary }]}>Pilot</Text>
      </View>

      {/* Right actions */}
      {rightActions && (
        <View style={styles.actions}>
          {rightActions}
        </View>
      )}
    </View>
  );
}

export function HeaderIconButton({
  onPress,
  children,
  active,
}: {
  onPress: () => void;
  children: React.ReactNode;
  active?: boolean;
}) {
  const { colors } = useTheme();
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[
        styles.iconBtn,
        active && { backgroundColor: colors.primaryC }
      ]}
      activeOpacity={0.7}
    >
      {children}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: 0.5,
  },
  wordmark: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  thin: {
    fontSize: 22,
    fontWeight: '200',
    letterSpacing: -0.5,
  },
  bold: {
    fontSize: 22,
    fontWeight: '600',
    letterSpacing: -0.5,
  },
  actions: {
    flexDirection: 'row',
    gap: 8,
  },
  iconBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
