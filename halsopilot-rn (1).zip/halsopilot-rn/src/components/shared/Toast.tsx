import React, { useEffect, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Animated,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useToast, type ToastMessage, type ToastType } from '@/context/ToastContext';
import { useTheme } from '@/context/ThemeContext';

export function ToastContainer() {
  const { toasts, dismiss } = useToast();
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.container, { top: insets.top + 58 }]} pointerEvents="box-none">
      {toasts.map(toast => (
        <ToastItem key={toast.id} toast={toast} onDismiss={() => dismiss(toast.id)} />
      ))}
    </View>
  );
}

function ToastItem({ toast, onDismiss }: { toast: ToastMessage; onDismiss: () => void }) {
  const { colors } = useTheme();
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.spring(anim, {
      toValue: 1,
      useNativeDriver: true,
      tension: 100,
      friction: 10,
    }).start();
  }, []);

  const bg: Record<ToastType, string> = {
    success: colors.secondaryC,
    info:    colors.primaryC,
    warning: colors.warnC,
    error:   colors.errorC,
  };
  const accent: Record<ToastType, string> = {
    success: colors.secondary,
    info:    colors.primary,
    warning: colors.warn,
    error:   colors.error,
  };

  return (
    <Animated.View style={[
      styles.toast,
      { backgroundColor: bg[toast.type] },
      {
        opacity: anim,
        transform: [{ translateY: anim.interpolate({ inputRange: [0,1], outputRange: [-14,0] }) }],
      }
    ]}>
      {/* Icon dot */}
      <View style={[styles.iconDot, { backgroundColor: accent[toast.type] }]} />

      {/* Content */}
      <View style={styles.body}>
        <Text style={[styles.title, { color: accent[toast.type] }]}>{toast.title}</Text>
        {toast.message ? (
          <Text style={[styles.msg, { color: colors.onSurface2 }]}>{toast.message}</Text>
        ) : null}
      </View>

      {/* Action */}
      {toast.actionLabel && (
        <TouchableOpacity onPress={() => { toast.actionFn?.(); onDismiss(); }}>
          <Text style={[styles.action, { color: accent[toast.type] }]}>{toast.actionLabel}</Text>
        </TouchableOpacity>
      )}

      {/* Close */}
      <TouchableOpacity onPress={onDismiss} style={styles.close}>
        <Text style={{ color: colors.outline, fontSize: 16 }}>×</Text>
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 999,
    gap: 8,
  },
  toast: {
    borderRadius: 16,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.14,
    shadowRadius: 10,
    elevation: 4,
  },
  iconDot: {
    width: 28,
    height: 28,
    borderRadius: 14,
  },
  body: {
    flex: 1,
  },
  title: {
    fontSize: 13,
    fontWeight: '600',
  },
  msg: {
    fontSize: 12,
    marginTop: 1,
  },
  action: {
    fontSize: 12,
    fontWeight: '600',
    paddingHorizontal: 4,
  },
  close: {
    padding: 4,
  },
});
