import React, { createContext, useContext, useState, useCallback } from 'react';
import { Colors } from '@/constants/tokens';

type Theme = 'light' | 'dark';

interface ThemeContextValue {
  theme: Theme;
  colors: typeof Colors;
  isDark: boolean;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>('light');
  const isDark = theme === 'dark';

  const toggleTheme = useCallback(() => {
    setTheme(t => t === 'light' ? 'dark' : 'light');
  }, []);

  // Merge dark overrides when in dark mode
  const colors = isDark
    ? { ...Colors, ...Colors.dark } as typeof Colors
    : Colors;

  return (
    <ThemeContext.Provider value={{ theme, colors, isDark, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used inside ThemeProvider');
  return ctx;
}
